# 29 Investor Memo

**Project:** OPENCAAD
**Upstream:** https://github.com/CAADRIA/opencaad

Content specific to OPENCAAD in category ARCHITECTURAL_DESIGN.
